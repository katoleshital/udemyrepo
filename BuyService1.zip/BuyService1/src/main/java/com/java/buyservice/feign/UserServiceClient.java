package com.java.buyservice.feign;

import javax.validation.Valid;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.java.buyservice.entity.User;

@FeignClient(name = "userservice")
public interface UserServiceClient {

	// Getting User by passing userId from USERSERVICE

	/*
	 * @GetMapping("/users/{userId}") public User getUserByUserId(@PathVariable
	 * Integer userId);
	 */

	@GetMapping("/users/{userId}")
	public User getUserByUserId(@Valid @PathVariable Integer userId);
}
