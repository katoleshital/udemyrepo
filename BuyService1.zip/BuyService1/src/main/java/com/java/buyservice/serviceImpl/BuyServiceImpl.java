package com.java.buyservice.serviceImpl;

import java.time.LocalDateTime;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;

import com.java.buyservice.dto.CourseResponseDto;
import com.java.buyservice.entity.Course;
import com.java.buyservice.entity.Purchase;
import com.java.buyservice.entity.User;
import com.java.buyservice.exception.CourseNotFoundException;
import com.java.buyservice.feign.CourseServiceClient;
import com.java.buyservice.feign.UserServiceClient;
import com.java.buyservice.repo.PurchaseRepository;
import com.java.buyservice.service.BuyService;

@Service
public class BuyServiceImpl implements BuyService {
	@Autowired
	CourseServiceClient courseServiceClient;
	@Autowired
	UserServiceClient userServiceClient;
	@Autowired
	PurchaseRepository purchaseRepository;

	@Override
	public String buyCourse(@Valid Integer courseId, Integer userId) throws CourseNotFoundException{
		User opUser = userServiceClient.getUserByUserId(userId);
		CourseResponseDto opCourse = courseServiceClient.viewCourseByCourseId(courseId);
		if ((opUser == null) || (opCourse == null)) {
			return "Purchase Unsuccessfull";
		}
		Purchase purchase = new Purchase();
		purchase.setCourseId(courseId);
		purchase.setUserId(userId);
		purchase.setDateTime(LocalDateTime.now());
		purchase.setStatus("PURCHASED");
		purchaseRepository.save(purchase);
		return opCourse.getCourseName() + " Course purchased Successfully by  " + opUser.getUserName();
	}

}
