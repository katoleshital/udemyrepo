package com.java.buyservice.service;

import javax.validation.Valid;

import com.java.buyservice.exception.CourseNotFoundException;

public interface BuyService {

	String buyCourse(@Valid Integer courseId, Integer userId)throws CourseNotFoundException;

}
